/*
 * File: Task_4.h
 *
 * Code generated for Simulink model 'Task_4'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.6 (R2021b) 05-Nov-2021
 * C/C++ source code generated on : Thu Dec  2 16:37:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Task_4_h_
#define RTW_HEADER_Task_4_h_
#ifndef Task_4_COMMON_INCLUDES_
#define Task_4_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* Task_4_COMMON_INCLUDES_ */

#include "Task_4_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay1_DSTATE;            /* '<S1>/Unit Delay1' */
  real_T UnitDelay_DSTATE;             /* '<S1>/Unit Delay' */
} DW_Task_4_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T errorsignal;                  /* '<Root>/error signal' */
} ExtU_Task_4_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T PIDoutput;                    /* '<Root>/PID output' */
} ExtY_Task_4_T;

/* Real-time Model Data Structure */
struct tag_RTM_Task_4_T {
  const char_T * volatile errorStatus;
};

/* Block states (default storage) */
extern DW_Task_4_T Task_4_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_Task_4_T Task_4_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_Task_4_T Task_4_Y;

/* Model entry point functions */
extern void Task_4_initialize(void);
extern void Task_4_step(void);
extern void Task_4_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Task_4_T *const Task_4_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Task_4'
 * '<S1>'   : 'Task_4/Subsystem'
 */
#endif                                 /* RTW_HEADER_Task_4_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
