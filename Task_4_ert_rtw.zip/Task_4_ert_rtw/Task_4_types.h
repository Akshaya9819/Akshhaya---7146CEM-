/*
 * File: Task_4_types.h
 *
 * Code generated for Simulink model 'Task_4'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.6 (R2021b) 05-Nov-2021
 * C/C++ source code generated on : Thu Dec  2 16:37:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Task_4_types_h_
#define RTW_HEADER_Task_4_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_Task_4_T RT_MODEL_Task_4_T;

#endif                                 /* RTW_HEADER_Task_4_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
