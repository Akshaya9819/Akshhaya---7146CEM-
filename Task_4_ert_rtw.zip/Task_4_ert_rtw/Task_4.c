/*
 * File: Task_4.c
 *
 * Code generated for Simulink model 'Task_4'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.6 (R2021b) 05-Nov-2021
 * C/C++ source code generated on : Thu Dec  2 16:37:12 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. MISRA C:2012 guidelines
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Task_4.h"
#include "Task_4_private.h"

/* Block states (default storage) */
DW_Task_4_T Task_4_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Task_4_T Task_4_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Task_4_T Task_4_Y;

/* Real-time model */
static RT_MODEL_Task_4_T Task_4_M_;
RT_MODEL_Task_4_T *const Task_4_M = &Task_4_M_;

/* Model step function */
void Task_4_step(void)
{
  /* Sum: '<S1>/Add1' incorporates:
   *  Gain: '<S1>/Gain1'
   *  Gain: '<S1>/Gain2'
   *  Inport: '<Root>/error signal'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  Task_4_DW.UnitDelay1_DSTATE += 300.0 * Task_4_U.errorsignal * 0.01;

  /* Outport: '<Root>/PID output' incorporates:
   *  Gain: '<S1>/Gain'
   *  Gain: '<S1>/Gain3'
   *  Inport: '<Root>/error signal'
   *  Sum: '<S1>/Add'
   *  Sum: '<S1>/Add2'
   *  UnitDelay: '<S1>/Unit Delay'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  Task_4_Y.PIDoutput = (600.0 * Task_4_U.errorsignal +
                        Task_4_DW.UnitDelay1_DSTATE) + (Task_4_U.errorsignal -
    Task_4_DW.UnitDelay_DSTATE) * 200.0;

  /* Update for UnitDelay: '<S1>/Unit Delay' incorporates:
   *  Inport: '<Root>/error signal'
   */
  Task_4_DW.UnitDelay_DSTATE = Task_4_U.errorsignal;
}

/* Model initialize function */
void Task_4_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void Task_4_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
